﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IseAlimBasvuruApp.Application.DTOs
{
    public class SifreSifirlaDTO
    {
        public string KullaniciId { get; set; }
        public string YeniSifre { get; set; }
    }
}
