﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IseAlimBasvuruApp.Application.DTOs
{
    public class KayitSonucuDTO
    {
        public bool BasariliMi { get; set; }
        public string Mesaj { get; set; }
    }
}
