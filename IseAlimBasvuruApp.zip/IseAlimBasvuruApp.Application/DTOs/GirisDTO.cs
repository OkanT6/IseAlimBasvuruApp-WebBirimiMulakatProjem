﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IseAlimBasvuruApp.Application.DTOs
{
    public class GirisDTO
    {
        public string Email { get; set; }
        public string Sifre { get; set; }
    }
}
