﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IseAlimBasvuruApp.DataAccess.Enums
{
    public enum Deneyim
    {
        Yeni_Başlayan,
        Orta_Seviye,
        İleri_Seviye
    }
}
