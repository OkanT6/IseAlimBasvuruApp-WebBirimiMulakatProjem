﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IseAlimBasvuruApp.DataAccess.Enums
{
    public enum CalismaTipi
    {
        Full_Time,
        Part_Time,
        Dönemsel_Proje_Bazlı,
        Staj,
        Serbest_Zamanli

    }
}
