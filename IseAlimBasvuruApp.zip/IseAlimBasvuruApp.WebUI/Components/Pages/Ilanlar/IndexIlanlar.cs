﻿//using IseAlimBasvuruApp.Application.DTOs;
using IseAlimBasvuruApp.Domain.DTOs;
using IseAlimBasvuruApp.Domain.Models;
using Microsoft.AspNetCore.Components;
using System.Net.Http;
using System.Text.Json;

namespace IseAlimBasvuruApp.WebUI.Components.Pages.Ilanlar
{
    public partial class IndexIlanlar
    {
        public List<IlanYayinDTO> ilanlar { get; set; }

        // HttpClient'ı doğrudan injekte et
        [Inject]
        public HttpClient HttpClient { get; set; }

        protected override async Task OnInitializedAsync()
        {
            // HttpClient ile API'ye GET isteği gönder
            using (var response = await HttpClient.GetAsync("https://localhost:7190/api/Ilan/ilanlariListeleAktif"))
            {
                if (response.IsSuccessStatusCode)
                {
                    // Yanıtı al ve JSON olarak deserialize et
                    var jsonString = await response.Content.ReadAsStringAsync();

                    ilanlar = JsonSerializer.Deserialize<List<IlanYayinDTO>>(jsonString, new JsonSerializerOptions
                    {
                        PropertyNameCaseInsensitive = true // JSON'daki küçük harf duyarlılığını kapat
                    });
                }
                else
                {
                    // Hata durumunda işlem yapılabilir
                    // Örneğin: ilanlar = new List<IlanYayinDTO>(); gibi bir şey yapılabilir.
                }
            }

            await base.OnInitializedAsync();
        }
    }
}
